#include<iostream>
#include<iomanip>
using namespace std;
struct s_memo
{
    int nVal;
    char cVal[100];
};
  
// declaring union
  
union u_memo
{
    int nVal;
    char cVal[100];
};
  
int main()
{
    struct s_memo s={18,"RDX"};
    union u_memo u={12};/*Union does not take char*/
  
    cout<<"structure data: "<<endl <<"integer value: "<<s.nVal<<endl<<"Char Value: "<<s.cVal<<endl;
    cout<<"\nunion data: "<<endl <<"integer value: "<<u.nVal<<endl<<"Char Value: "<<u.cVal<<endl;
    cout<<"\nsizeof structure :  "<<sizeof(s)<<endl;
    cout<<"sizeof union :  "<<sizeof(u);
}
