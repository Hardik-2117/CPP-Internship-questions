#include<iostream>
#include<iomanip>
using namespace std;

struct Data
{
    int num1;
    int num2;
    int num3;
    int average;
};
struct Data CalculateAvg();
int main()
{
	struct Data *ptr,d;
	ptr=&d;
	d=CalculateAvg();
	cout<<"Average of three number is : "<<(*ptr).average;	
}
struct Data CalculateAvg()
{
	struct Data *ptr1,d1;
	ptr1=&d1;
	cout<<"Enter tha value of num1: ";
	cin>>(*ptr1).num1;
	cout<<"Enter tha value of num1: ";
	cin>>(*ptr1).num2;
	cout<<"Enter tha value of num1: ";
	cin>>(*ptr1).num3;
	(*ptr1).average = ((*ptr1).num1 + (*ptr1).num2 + (*ptr1).num3)/3;
	return (*ptr1);
}
