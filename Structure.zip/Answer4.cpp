#include<iostream>
#include<iomanip>
using namespace std;

struct BATSMAN
{
    char name[100];
    int age;
    int high_score;
    int least_score;
    int no_of_ducks;
};

struct BATSMAN DATA(struct BATSMAN bat2[3]);

void printdata(struct BATSMAN bat2[3])
{
	cout<<"\nDisplaying Information \n";
	cout << "Name" <<setw(15)<<" Age " <<setw(10)<<" High_Score " <<setw(10)<<" Least_Scopre " <<setw(10)<<" Number of duck ";
    cout<<endl;
	for(int i=0;i<3;i++)
    {
	cout << "\n"<< bat2[i].name <<setw(15)<< bat2[i].age <<setw(10)<< bat2[i].high_score<<setw(10)<< bat2[i].least_score<<setw(10)<< bat2[i].no_of_ducks;		
}
}
int main()
{
    int i, n;  
    struct BATSMAN bat[3]; 
    for(i=0;i<3;i++)
    {
    cout << "\nEnter details of "<<i+1<<"  Batsman"<<endl;
    cout <<setw(5)<< "\nEnter Name : ";
    cin >> bat[i].name;
    cout <<setw(5)<< "Enter Age : ";
    cin >>  bat[i].age;
    cout <<setw(5)<< "Enter High Score : ";
    cin >>  bat[i].high_score;
    cout <<setw(5)<< "Enter Least Score : ";
    cin >>  bat[i].least_score;
    cout <<setw(5)<< "Enter Number of Ducks : ";
    cin >>  bat[i].no_of_ducks;
    }
    printdata(bat);
    return 0;
}
