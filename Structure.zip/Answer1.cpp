#include<iostream>
#include<iomanip>
using namespace std;

struct Emp
{
    char emp_Name[50];
    int emp_id;
    int emp_age;
    float emp_salary;
};

int main()
{ 
  
 Emp e1,e2,e3;
 cout<<"\nEnter The employ data \n";
 cout<<"\n1. emp_Name\n";
 cout<<"\n2. emp_id\n";
 cout<<"\n3. emp_age\n";
 cout<<"\n4.emp_salary\n";
  
 cout<<"\nEnter The first  of Employee\n\n";
    cin >> e1.emp_Name;
    cin >> e1.emp_id;
    cin >> e1.emp_age;
    cin >> e1.emp_salary;
    
     cout<<"\nEnter The second  of Employee\n\n";
    cin >> e2.emp_Name;
    cin >> e2.emp_id;
    cin >> e2.emp_age;
    cin >> e2.emp_salary;
    
    cout<<"\nEnter The third of Employee\n\n";
    cin >> e3.emp_Name;
    cin >> e3.emp_id;
    cin >> e3.emp_age;
    cin >> e3.emp_salary;
 

 cout<<"\n\n------------------------------------------------------------\n";
    cout << "Details of Employees";
 cout<<"\n------------------------------------------------------------\n\n";
    
    cout << "ID" <<setw(15)<<"Name" <<setw(10)<<"Age" <<setw(10)<<"Salary";
    cout<<endl;

     cout << "\n"<< e1.emp_Name <<setw(15)<< e1.emp_id <<setw(10)<< e1.emp_age<<setw(10)<< e1.emp_salary;
      cout << "\n"<< e2.emp_Name <<setw(15)<< e2.emp_id <<setw(10)<< e2.emp_age <<setw(10)<< e2.emp_salary;
       cout << "\n"<< e3.emp_Name <<setw(15)<< e3.emp_id <<setw(10)<< e3.emp_age <<setw(10)<< e3.emp_salary;
    cout<<"\n\n------------------------------------------------------------\n";
     
    cout<<"Size of struct Emp: "<<sizeof(struct Emp)<<endl;

}

