#include<iostream>
#include<iomanip>
#include<algorithm>
using namespace std;

struct Student
{
    char student_name[100];
    int roll_no;
    int marks_1;
    int marks_2;
    int marks_3;
};

int main()
{
    int i, n,a[n];  
 cout<<"\nEnter The Number of Student\n\n";
 cin>>n;
 
 Student Stu[n]; 
 
    for(i=0;i<n;i++)
    {
    cout << "\nEnter details of " << i+1 << " Student"<<endl;
    cout <<setw(5)<< "\nEnter student_name : ";
    cin >> Stu[i].student_name;
    cout <<setw(5)<< "\nEnter roll_no : ";
    cin >>  Stu[i].roll_no;
    cout <<setw(5)<< "\nEnter marks_1 : ";
    cin >>  Stu[i].marks_1;
    cout <<setw(5)<< "\nEnter marks_2 : ";
    cin >>  Stu[i].marks_2;
    cout <<setw(5)<< "\nEnter marks_3 : ";
    cin >>  Stu[i].marks_3;
   
 }
 cout<<"\n\n------------------------------------------------------------\n";
    cout << "Details of Student";
 cout<<"\n------------------------------------------------------------\n\n";
    cout << "student_name" <<setw(15)<<"roll_no" <<setw(10)<<"marks_1" <<setw(10)<<"marks_2"<<setw(10)<<"marks_3";
    cout<<endl;
 for(i=0;i<n;i++)
    {
     cout << "\n"<< Stu[i].student_name<<setw(15)<< Stu[i].roll_no <<setw(10)<<  Stu[i].marks_1 <<setw(10)<< Stu[i].marks_2 <<setw(10)<< Stu[i].marks_3;
    }
    cout<<"\n\n------------------------------------------------------------\n";
    cout<<"Avrage of Marks";
    for(i=0;i<n;i++)
    {
    cout << "\nAvrage Marks of " << i+1 << " Student"<<endl;
    a[i]=(Stu[i].marks_1 + Stu[i].marks_2 + Stu[i].marks_3)/3;
    cout<<a[i];
}
 cout<<"\n\n------------------------------------------------------------\n";
 
}

