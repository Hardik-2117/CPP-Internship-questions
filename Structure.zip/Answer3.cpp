#include<iostream>
#include<iomanip>
using namespace std;

struct Data
{
    int num1;
    int num2;
    int num3;
    int average;
};
struct Data CalculateAvg();
int main()
{
	struct Data d;
	d=CalculateAvg();
	cout<<"Average of three number is : "<<d.average;	
}
struct Data CalculateAvg()
{
	struct Data d1;
	cout<<"Enter tha value of num1: ";
	cin>>d1.num1;
	cout<<"Enter tha value of num1: ";
	cin>>d1.num2;
	cout<<"Enter tha value of num1: ";
	cin>>d1.num3;
	d1.average = (d1.num1 + d1.num2 + d1.num3)/3;
	return d1;
}
