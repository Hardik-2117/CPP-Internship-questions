#include<iostream>
using namespace std;
struct data1{
	char c;
	int x;
};
struct data2{
	char arr[10];
	int x;
};
struct data3{
	char arr[10];
	long int x;
};
struct data4{
	char arr[100];
	int x;
};
int main(){
	int size1,size2,size3,size4;
	struct data1 d1;
	struct data2 d2;
	struct data3 d3;
	struct data4 d4;
	size1=sizeof(d1);
	size2=sizeof(d2);
	size3=sizeof(d3);
	size4=sizeof(d4);
	cout<<"Size of first Structure : "<<size1<<endl;
	cout<<"Size of second Structure : "<<size2<<endl;
	cout<<"Size of third Structure : "<<size3<<endl;
	cout<<"Size of fourth Structure : "<<size4<<endl;
}
/*
Size of first Structure : 8

Size of second Structure : 16

Size of third Structure : 16

Size of fourth Structure : 104    */
