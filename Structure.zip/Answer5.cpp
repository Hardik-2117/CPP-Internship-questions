#include<iostream>
#include<iomanip>
#include <stdlib.h>
using namespace std;
typedef struct EMP {
   char emp_name[50];
    int emp_id;
    int emp_age;
   float emp_salary;
}e1;
int main()
{
   e1 *eptr;
   int i, n;
   cout<<"Enter the number of persons: ";
   cin>>n;
   eptr = (e1*) malloc(n * sizeof(e1));
   cout<<"Enter detail of EMP : "<<endl;
   for(i = 0; i < n; ++i)
   {
       cout<<"\n\n"<<"Enter emp_name: ";         
       cin>>(eptr+i)->emp_name;
       cout<<"Enter emp_id: ";
	   cin>>(eptr+i)->emp_id;
	   cout<<"Enter emp_age: ";
	   cin>>(eptr+i)->emp_age;
	   cout<<"Enter emp_salary: ";
	   cin>>(eptr+i)->emp_salary;
   }

   printf("Displaying Information:\n");
   cout<<"\n\n"<<"emp_name"<<setw(15)<<"emp_id"<<setw(15)<<"emp_age"<<setw(15)<<"emp_salary";
   for(i = 0; i < n; ++i)
       cout<<"\n"<<(eptr+i)->emp_name<<setw(15)<<(eptr+i)->emp_id<<setw(15)<<(eptr+i)->emp_age<<setw(15)<<(eptr+i)->emp_salary;

   return 0;
}
