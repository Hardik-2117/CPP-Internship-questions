#include<iostream>
#include<iomanip>
using namespace std;
struct EMP {
   char emp_name[50];
    int emp_id;
    int emp_age;
   float emp_salary;
};
int main()
{
	EMP *e1,person1;
	e1 = &person1;
	EMP *e2,person2;
	e2 = &person2;
	EMP *e3,person3;
	e3 = &person3;
	
	
	cout<<"\n"<<"Enter first employe name: ";
    cin>>(*e1).emp_name;
    cout<<"\n"<<"Enter first employe ID: ";
    cin>>(*e1).emp_id;
	cout<<"\n"<<"Enter first employe age: ";
    cin>>(*e1).emp_age;
	cout<<"\n"<<"Enter first employe salary: ";
	cin>>(*e1).emp_salary;
	cout<<"................................. second .........................................................";
	cout<<"\n"<<"Enter second employe name: ";
    cin>>(*e2).emp_name;
    cout<<"\n"<<"Enter second employe id: ";
    cin>>(*e2).emp_id;
	cout<<"\n"<<"Enter second employe age: ";
    cin>>(*e2).emp_age;
	cout<<"\n"<<"Enter second employe salary: ";
	cin>>(*e2).emp_salary;
	cout<<"................................... Third .......................................................";
	cout<<"\n"<<"Enter Third employe name: ";
    cin>>(*e3).emp_name;
    cout<<"\n"<<"Enter Third employe id: ";
    cin>>(*e3).emp_id;
	cout<<"\n"<<"Enter Third employe age: ";
    cin>>(*e3).emp_age;
	cout<<"\n"<<"Enter Third employe salary: ";
	cin>>(*e3).emp_salary;
	cout<<"................................... Displaying .......................................................";
    printf("Displaying:\n");
    cout<<"\n\n"<<"emp_name"<<setw(15)<<"emp_id"<<setw(15)<<"emp_age"<<setw(15)<<"emp_salary";
    cout<<"\n"<<(*e1).emp_name<<setw(15)<<(*e1).emp_id<<setw(15)<<(*e1).emp_age<<setw(15)<<(*e1).emp_salary;
    
    cout<<"\n"<<(*e2).emp_name<<setw(15)<<(*e2).emp_id<<setw(15)<<(*e2).emp_age<<setw(15)<<(*e2).emp_salary;
    
    cout<<"\n"<<(*e3).emp_name<<setw(15)<<(*e3).emp_id<<setw(15)<<(*e3).emp_age<<setw(15)<<(*e3).emp_salary;
}
