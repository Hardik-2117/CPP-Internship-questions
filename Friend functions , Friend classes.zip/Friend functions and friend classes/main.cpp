/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
#include <ostream>
#include <istream>
using std::cin;
using std::cout;
using std::endl;
using std::string;
using std::istream;
using std::ostream;
class Date
{

public:
    int d;
    Date():d(25){}
     friend Date operator+(Date d1,int i)
    {
        Date d2;
        d2.d=d1.d+1;
        return d2;
    }
};
int main()
{
    Date d1, d2;
    d2 = d1 + 1;
    cout<<d2.d; 
}


