/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <iostream>
using std::cin;
using std::cout;
using std::endl;
class Sample
{
private:
    int x;
    double y;
public :
    Sample()
    {
        x=0;
        y=0;
        cout<<"x = "<<x<<" y = "<<y<<endl;
    }
    Sample(int x)
    {
        this->x=x;
        y=0;
        cout<<"x = "<<x<<" y = "<<y<<endl;
    }
    Sample(int x,int y)
    {
        this->x=x;
        this->y=y;
        cout<<"x = "<<x<<" y = "<<y<<endl;
    }
    Sample(int x,double y)
    {
        this->x=x;
        this->y=y;
        cout<<"x = "<<x<<" y = "<<y<<endl;
    }
};
int main()
{
    int x;
    double y;
    cin>>x>>y;
    Sample s;
    Sample s1(x);
    Sample s2(x,x);
    Sample s3(x,y);
}