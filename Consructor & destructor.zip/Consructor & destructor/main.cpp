/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
using std::cin;
using std::cout;
using std::endl;
class Point
{
    public:
    Point()
    {
        cout<<"Point constructor"<<endl;
    }
};
class Queue
{
    public:
    Queue()
    {
        cout<<"Queue constructor"<<endl;
    }
};
class Employee
{
    public:
    Employee()
    {
        cout<<"Employee constructor"<<endl;
    }
};
int main()
{
    Point p;
    Queue a;
    Employee e;
}