/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include<iostream>
using namespace std;
int main() {
   int i, n,a,b;
   cout<<"Enter the number: ";
   cin>>i;
   cout<<"enter the position: ";
   cin>>n;
   a=b=i;
   
   cout<<"1 bit to be set"<<endl;
   a |=(1 << n);
   cout << a<<"\n";
   
   cout<<"0 bit to be cleared"<<endl;
   i &= ~(0 << n);
   cout << i<<"\n" ;
   
   cout<<"n bit to be toggled: "<<n;
   b ^= (1 << n);
   cout << b<<"\n";
   return 0;
}
