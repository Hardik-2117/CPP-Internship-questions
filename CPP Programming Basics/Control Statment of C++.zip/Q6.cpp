#include <iostream>
using namespace std;
int main() {
	int l,r,k,i,count=0;
	cin>>l>>r>>k;
	for(i=1;i<=r;i++){
		if(i%k==0){
			count++;
		}
		else count=count;
	}
	cout<<count;
}
