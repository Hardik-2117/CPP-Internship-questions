/**************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

***************************/
#include <iostream>
using namespace std;

int main() {
    int amount;
    cout<<"Enter amount to be withdrawn:";
    cin>>amount;
    cout<<"Cashier gives you 1000 currency notes of "<<(amount/1000)<<endl<<"OR"<<endl;
    cout<<"200 currency notes of "<<(amount/200)<<endl<<"OR"<<endl;
    cout<<"100 currency notes of "<<(amount/100)<<endl;
   
    
}
