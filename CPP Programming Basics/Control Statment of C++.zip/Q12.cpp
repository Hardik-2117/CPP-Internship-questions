#include <iostream>
using namespace std;

int main()
{
    int space, rows;
    char c;

    cout <<"Enter number of rows: ";
    cin >> rows;
    cout <<"Enter the character: ";
    cin >> c;
    cout << endl;

    for(int i = 1, k = 0; i <= rows; ++i, k = 0)
    {
        for(space = 1; space <= rows-i; ++space)
        {
            cout <<"  ";
        }

        while(k != 2*i-1)
        {   
            cout <<" "<<c;
            ++k;
        }
        cout << endl;
    }    
    return 0;
}
