
/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
int seconds, hours, minutes;
cout<<"Enter the time in second: ";
cin >> seconds;
minutes = seconds / 60;
hours = minutes / 60;
cout << " The time is " << int(hours) << " hours " << int(minutes%60) 
     << " minutes " << int(seconds%60) << " seconds.";
 }
