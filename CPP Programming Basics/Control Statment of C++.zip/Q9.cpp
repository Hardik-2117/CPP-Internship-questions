#include <iostream>
using namespace std;
int main()   
{    
int n,sum=0,m,a;    
cout<<"Input Number is:";    
cin>>n; 
a=n;   
while(n>0)    
{    
m=n%10;    
sum=sum+m;    
n=n/10;    
}    
cout<<"The Sum of the digits of " <<a <<" is= "<<sum;    
return 0;  
}   
