#include <iostream>
using namespace std;
int main()   
{    
int n,r,a,sum=0,temp;    
cout<<"enter the number=";    
cin>>n;
a=n;    
temp=n;    
while(n>0)    
{    
r=n%10;    
sum=(sum*10)+r;    
n=n/10;    
}    
if(temp==sum)    
cout<<a<<" is palindrome number ";    
else    
cout<<a<< " is not palindrome";   
return 0;  
}   
