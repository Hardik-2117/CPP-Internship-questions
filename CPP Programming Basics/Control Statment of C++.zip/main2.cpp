/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
using namespace std;
int main(){
    int r,num,temp,sum=0,i,temp_sum=0;
    cout<<"Enter a number : ";
    cin>>num;

    cout<<"\nNew number by adding one to each digit is :";

    while(num!=0){
        r=num%10;
        temp=r+1;
        if(temp==10)
            temp=0;
    num=num/10;
    sum=(sum*10)+temp;}

    while(sum!=0){
        i=sum%10;
        sum=sum/10;
        temp_sum=(temp_sum*10)+i;
}
    cout<<" "<<temp_sum;
}
