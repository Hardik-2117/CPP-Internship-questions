/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
using std::cin;
using std::cout;
using std::endl;
using std::string;
class String
{
    string s;
public:
    String(string str="abcd"):s(str){}
    char &operator[](int i)
    {
        return s[i];
    }
    void display()
    {
        cout<<"String is "<<s<<endl;
    }
};
int main()
{
    String   s("abcd");
    char  ch;
    s[0] = 'A';
    s.display();
    ch = s[1];
    cout<<"ch is "<<ch<<endl;
}




