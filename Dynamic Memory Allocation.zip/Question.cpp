#include <iostream>
using namespace std;

int main ()
{
	int *p = NULL;
	p = new int;
	if (!p)
		cout << "allocation of memory failed\n";
	else
	{
        cout<< "Enter the number: ";
        cin >>*p;
		cout << "\nThe entered number is: " << *p << endl;
	}

	delete p;

	return 0;
}
