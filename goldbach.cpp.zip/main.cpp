/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;
int prime(int n)
{
    int c=0,i;
    for(i=1;i<=n;i++)
    {
        if(n%i==0)
        {
            c++;
        }
    }
    if(c==2)
       return true;
    else
       return false;
}
int main()
{
    int a[100];
    int i,j,k=0,num;
    cout<<"\nEnter any even number\n ";
    cin>>num;
    for(i=1;i<=num;i++)
    {
        if(prime(i))
        {
            a[k]=i;
            k++;
        }
    }
    for(i=0;i<k;i++)
    {
        for(j=i+1;j<k;j++)
        {
            if(a[i]+a[j]==num)
               cout<<num<<" "<<a[i]<<" "<<a[j]<<endl;
        }
    }
}