#include <iostream>
using namespace std;
int main()
{
    int arr1[3][3],i,j,sum1,sum2;
    int sa[10],k=0;
    cout<<"Enter elements for 3 * 3 matrix\n";
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
        	cout<<i<<j<<": ";
            cin>>arr1[i][j];
            sa[k]=arr1[i][j];
            if(sa[k]>9){
            	cout<<"Enter only 1 to 9 value";
               return 0;
			}
               
            k++;

        }
    }
    for(int i=0;i<9; i++)
    {
        for(int j=i+1;j<9;j++)
        {
            if(sa[i] == sa[j])
            {
                cout<<"\nDublecate element present";
                return 0;
            }
        }
    }
    cout<<"Matrix Elements are\n";
    for(i=0;i<3;i++)
    {
        for(j=0;j<3;j++)
        {
            cout<<" "<<arr1[i][j];
        }
        cout<<"\n";
    }
    
 sum1=arr1[0][0]+arr1[0][2]+arr1[2][2]+arr1[2][0];
 sum2=arr1[0][1]+arr1[1][2]+arr1[2][1]+arr1[1][0];
 if(sum1>sum2)
    cout<<"\nThe above matrix is corner-heavy : 1";
else if(sum1<sum2)
    cout<<"\nThe above matrix is center-heavy : 2";
else
    cout<<"\nThe above matrix is balanced : 3"; 
}
