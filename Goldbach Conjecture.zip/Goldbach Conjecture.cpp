#include <iostream>
#include<stdlib.h>
using namespace std;

int main()
{
    int n,arr[1000],k=0,p=0,j,a[4],check=0;
    for(int i=0;i<4;i++)
    {
        cout<<"Enter any number"<<endl;
        cin>>a[i];
    }
    for(int i=0;i<4;i++)
    {
        here:
        if(check==1)
        i++;
        n=a[i];
       if((n%2==0)&&(n>4))
       {
            for(int i=2;i<n;i++)
            {
                int flag=1;
                for(int j=2;j<i;j++)
                {
                    if(i%j==0)
                    {
                        flag=0;
                    }
                }
                if(flag==1)
                {
                    arr[k]=i;
                    k++;
                }
        }
        while(p<k)
            {
                for(int i=0;arr[i]<arr[p];i++)
                {
                    for(int j=0;arr[j]<arr[p];j++)
                    {
                        if(n==(arr[i]+arr[j]))
                        {
                            cout<<n<<" "<<arr[i]<<" "<<arr[j]<<endl;
                            check=1;
                            goto here;
                        }
                    }
                }
                p++;
        }
    } 
    }
    
    return 0;
}

