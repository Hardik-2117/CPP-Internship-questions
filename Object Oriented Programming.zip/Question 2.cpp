#include <iostream>
using namespace std;
class Rectangle{
    private:
        int tx, ty;
        int bx, by;
    public:
        void input(){
            cout<<"\nEnter the top left corner coordinates: tx , ty = ";
            cin >>tx>>ty ;
            cout<<"\nEnter the bottom right corner coordinates: bx , by = ";
            cin >>bx>>by ;
        }
        float Getwidth(){
            float width=bx-tx;
            cout<<"\nThe width of Rectangle: "<<width;
        }
        float GetHeight(){
            float height=ty-by;
            cout<<"\nThe height of Rectangle: "<<height;
        }
        void SetWidth(float newWidth)
        {
            this->bx=newWidth+tx;
        }
        void SetHeight(float newHeight)
        {
            this->ty=newHeight+by;
        }
        void getCoordinates()
        {
            cout<<endl;
            cout<<"tx: "<<tx<<" "<<"ty"<<ty<<endl;
            cout<<"bx: "<<bx<<" "<<"by"<<by<<endl;
        }
        
};
int main(){
    Rectangle r1;
    r1.input();
    r1.Getwidth();
    r1.GetHeight();
    r1.SetWidth(6);
    r1.SetHeight(5);
    r1.getCoordinates();
}
