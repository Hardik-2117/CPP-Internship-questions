#include <iostream>
#include<conio.h>
#include<string.h>
using namespace std;
class Student {
private:
	int admno;
	char sname[20];
	float eng;
	float math;
	float science;
	float total;
	float ctotal() {
		return eng + math + science;
	}
public:
	void Takedata(int admno, char sname[20], float eng, float math, float science) {
		this->admno = admno;
		strcpy(this->sname, sname);
		this->eng = eng;
		this->math = math;
		this->science = science;
		this->total = ctotal();
	}
	void Showdata() {
		cout<<"\nAdmno: " <<admno<<"\n";
		cout<<"Name: " <<sname<<"\n";
		cout<<"Eng: " <<eng <<"\n";
		cout<<"Math: " <<math <<"\n";
		cout<<"Science: " <<science <<"\n";
		cout<<"Total: " <<total <<"\n";
	}
};
int main(){
	Student st;
	int admno;
	char sname[20];
	float eng;
	float math;
	float science;
	cout<<"Enter admno: ";
	cin>>admno;
	cin.ignore();
	cout<<"Enter sname: ";
	gets(sname);
	cout<<"Enter eng: ";
	cin>>eng;
	cout<<"Enter math: ";
	cin>>math;
	cout<<"Enter science: ";
	cin>>science;
	st.Takedata(admno, sname, eng, math, science);
	st.Showdata();
	cout<<"\n\n";
	system("pause");
	return 0;
}
