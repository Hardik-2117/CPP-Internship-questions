/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
using namespace std;

int main() {
    float a, b,c,d,e;
    cout<<"Enter three value: ";
    cin >> a>>b>>c>>d>>e;
    cout<<"Enter first value: "<<a <<" "<<b <<" "<<c<<" "<< d <<" "<<e;
}
