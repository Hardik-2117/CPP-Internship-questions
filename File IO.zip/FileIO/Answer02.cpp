/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
#include <fstream>
using std::cin;
using std::cout;
using std::endl;
using std::ostream;
using std::string;
using std::fstream;
using std::ifstream;
using std::ofstream;
using std::ios;
class Message
{
    public:
    int i;
    float f;
    char c;
    public:
        Message(int i=0,float f=0,char c='\0')
        {
            this->i=i;
            this->f=f;
            this->c=c;
        }
    friend ostream &operator<<(ostream &COUT,Message &m)
    {
        COUT<<m.i<<m.f<<m.c;
        return COUT;
    }

};
int main()
    {
        fstream message;
        message.open("IMP_Messages.txt",ios::out);
        int i;
        float f;
        char c;
        cin>>i>>f>>c;
        message<<i<<" "<<f<<" "<<c<<endl;
        message.close();
        message.open("IMP_Messages.txt",ios::in);
        Message M;
        message>>M.i>>M.f>>M.c;
        cout<<M;
        message.close();
    }
