/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
using std::cin;
using std::cout;
using std::endl;
using std::string;
using std::istream;
using std::ostream;
class Vector
{
 int A[10];;
public:


    friend istream &operator>>(istream &CIN,Vector &v)
    {
        cout<<"Enter 10 numbers "<<endl;
        for(int i=0;i<10;i++)
        {
            CIN>>v.A[i];
        }
        return CIN;
    }
    friend ostream &operator<<(ostream &COUT,Vector &v)
    {
        cout<<"Entered 10 numbers "<<endl;
        for(int i=0;i<10;i++)
        {
            COUT<<v.A[i]<<" ";
        }
        return COUT;
    }
};
int main()
{
   Vector v;
   cin>>v;
   cout<<v;

}
