/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
#include <fstream>
#include <string.h>
using std::cin;
using std::cout;
using std::endl;
using std::ostream;
using std::string;
using std::fstream;
using std::ifstream;
using std::ofstream;
using std::ios;
struct Employee
{
    int employee_no;
    char employee_name[50];
    char employee_job[50];
    int employee_salary;
    int employee_dept_no;
};
int main()
{
    ofstream ofs("employee_db.txt",ios::out);
    struct Employee emp[10];
    for(int i=0;i<10;i++)
    {
        cout<<"Enter the details of an Employee "<<i+1<<" : "<<endl;
        cout<<"Employee number : ";
        cin>>emp[i].employee_no;
        cin.ignore();
        cout<<"Enter Employee name : ";
        cin.getline(emp[i].employee_name,50);
      //  cin.ignore();
        cout<<"Enter Employee job : ";
        cin.getline(emp[i].employee_job,50);
        cout<<"Enter Employe salary : ";
        cin>>emp[i].employee_salary;
        cout<<"Employee Department id : ";
        cin>>emp[i].employee_dept_no;
    }
    for(int i=0;i<10;i++)
    {
        ofs<<emp[i].employee_no<<emp[i].employee_name<<emp[i].employee_job<<emp[i].employee_salary<<emp[i].employee_dept_no<<endl;
    }
    ofs.close();
    ifstream ifs("employee_db.txt",ios::in);
    for(int i=0;i<10;i++)
    {
        ifs>>emp[i].employee_no>>emp[i].employee_name>>emp[i].employee_job>>emp[i].employee_salary>>emp[i].employee_dept_no;
    }
    for(int i=0;i<10;i++)
    {
        cout<<emp[i].employee_no<<" "<<emp[i].employee_name<<" "<<emp[i].employee_job<<" "<<emp[i].employee_salary<<" "<<emp[i].employee_dept_no<<endl;
    }
    int search_id;
    cout<<"Enter employee no to search : ";
    cin>>search_id;
    for(int i=0;i<10;i++)
    {
        if(search_id==emp[i].employee_no)
        {
            cout<<emp[i].employee_no<<"\n"<<emp[i].employee_name<<"\n"<<emp[i].employee_job<<"\n"<<emp[i].employee_salary<<"\n"<<emp[i].employee_dept_no<<endl;
            ifs.close();
            return 0;
        }
    }
     cout<<"No data found";
     return 0;
}

