#include <iostream>
using namespace std;

int findSmallestElement(int arr[], int n){
   int temp = arr[0];
   for(int i=0; i<n; i++) {
      if(temp>arr[i]) {
         temp=arr[i];
      }
   }
   return temp;
}


int main(void) {
	int arr[100];
    int n=5,i;
 
    cout<<"Enter elements in array: ";
    for(i=0; i<n; i++)
    {
        cin>>arr[i];
    }
    
   int smallest = findSmallestElement(arr, n);
   cout<<"smallest number in the array is : "<<smallest;
   return 0;
}
