#include <iostream>
using namespace std;
int main()
{
    
    int i, n;
    double sum=0, average=0;
    cout << "\n\nEnter the size of an array: ";
    cin >> n;
    int arr[n];
    cout << "\nEnter " << n << " number :\n\n";
    
    for (i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    for (i = 0; i < n; i++)
    {
        sum += arr[i];
    }
    average = sum/n;
    cout << " Sum of all elements in the array is : " << sum << "\n";
    cout << " Average of all input numbers : " << average << "\n\n";
    cout << "\n\n";
    return 0;
}
