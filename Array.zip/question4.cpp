#include <iostream>
using namespace std;

int main() {

  int i, n;
  float arr[100];

  cout << "Enter total number of elements: ";
  cin >> n;
  cout << endl;
  cout << "Enter" <<" " <<n << " "<< "elements of the array:";
  // Store number entered by the user
  for(i = 0; i < n; ++i) {
    cout <<" ";
    cin >> arr[i];
  }

  // Loop to store largest number to arr[0]
  for(i = 1;i < n; ++i) {

    // Change < to > if you want to find the smallest element
    if(arr[0] < arr[i])
      arr[0] = arr[i];
  }

  cout << endl << "Largest element is " << arr[0];

  return 0;
}
