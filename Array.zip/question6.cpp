#include <iostream>
using namespace std;

#define MAX 100

int main()
{
	//array declaration
	int arr[MAX];
	int n,i,j;
	int temp;
	
	//read total number of elements to read
	cout<<"Enter the number of elements of the array"<<endl;
	cin>>n;
	
	//check bound
	if(n<0 || n>MAX)
	{
		cout<<"Input valid range!!!"<<endl;
		return -1;
	}
	
	//read n elements
	cout<<"Enter the number"<<endl;
	for(i=0;i<n;i++)
	{
		cout<<" ";
		cin>>arr[i];
	}
	
	
	
	//sorting - Descending ORDER
	for(i=0;i<n;i++)
	{		
		for(j=i+1;j<n;j++)
		{
			if(arr[i]<arr[j])
			{
				temp  =arr[i];
				arr[i]=arr[j];
				arr[j]=temp;
			}
		}
	}
	
	//print sorted array elements
	cout<<"The numbers arranged in descending order are given below"<<endl;
	for(i=0;i<n;i++)
		cout<<arr[i]<<"\n";
	cout<<endl;	
		
	return 0;	
}



