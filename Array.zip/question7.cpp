#include<iostream>
using namespace std;
int main() {
int a[50],i,sum=0,count=0;
    cout<<"Enter upto 20 Values: "<<endl;
    for(i=0; i<20; i++)
        cin>>a[i];
    for(i=0; i<20; i++)
    {
        if(a[i]%2==0){
            sum=sum+a[i];
            count++;
        }
    }
    cout<<"Total Sum of Even values is: "<<sum<<endl;
    cout<<"Total number of Even values is: "<<count;
}
