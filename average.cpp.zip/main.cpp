/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include<iostream>
using namespace std;
int main()
{
  double a,b,c,d,e; 
  double average; 
  cout << "Enter five numbers: ";
  cin >> a >> b >> c >> d >> e;
  average = (a + b + c + d + e)/5;
  cout << "Average = " << average << endl;
  return 0;
}