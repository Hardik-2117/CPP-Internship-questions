#include<iostream>
#include<string.h>
using namespace std;
int weightOfString(char *input1,int input2)
{
	int weight=0,i=0;
	char *A ;
	A=input1;
	char letter;
	for (i=0;i<strlen(A);i++)
	{
		letter=A[i];
		if(input2==0)
		{
			if(letter=='a'||letter=='e'||letter=='i'||letter=='o'||letter=='u'||
			letter=='A'||letter=='E'||letter=='I'||letter=='O'||letter=='U')
			{
				continue;
			}
		}
		if(letter >=65 && letter <= 90){
			weight +=letter-64;
		}
		else if (letter >= 97 && letter <= 122){
			weight +=letter-96;
		}
	}
	return weight;
}
int main()
{
	char str[100];
	int num , x;
	cout<<"Input 1 = ";
	gets(str);
	cout<<"Input 2 : 0 or 1 = ";
	cin>>num;
	cout<< "Output 1 = "<<weightOfString(str,num);
	return 0;
}
