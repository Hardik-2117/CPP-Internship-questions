#include <iostream>
using namespace std;
string vowelstoZ(char *str)
{   	int a, len=0;
	for(int i=0;str[i]!='0';i++)
    {
        a=len++;
    }
	for (int i = 0; i < a; i++) {

		if (str[i] == 'A' || str[i] == 'E' || str[i] == 'I' || str[i] == 'O' || str[i] == 'U'||str[i] == 'a' || str[i] == 'e' || str[i] == 'i' || str[i] == 'o' || str[i] == 'u')
			str[i] = 'Z';
	}
	return str;
}
int main()
{
	char str[100];
	cout<<"Enter the string: ";
	cin >> str;
	cout <<"\n"<<"New string: " <<vowelstoZ(str);
	return 0;
}
