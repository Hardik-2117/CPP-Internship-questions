#include <bits/stdc++.h>
using namespace std;
int compare(char *str1,char *str2)
{
	int i=0,dif=0  ;
    for(i=0;str1[i]!='\0';i++)
    {
	    if(toupper(str1[i])!=toupper(str2[i]))
	        return 0;
    }
    return 1;
}
int main(){
	char str1[100],str2[100];
	cout<<"enter first string: ";
	cin>>str1;
	cout<<"enter second string: ";
	cin>>str2;
	if(compare(str1,str2))
	cout<<"Thay are identical";
	else
	cout<<"Thay are not identical";
	
}
