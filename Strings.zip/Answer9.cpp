#include<iostream>
#include<sstream>
#include<string>
using namespace std;
int mystrcat(string str1,int num,string str2,string str3);
string s(int num){
	stringstream ss;
	ss <<num;
	return ss.str();
}
int main()
{
	string str1,str2,str3;
	int num;
	cout <<"Enter the first string:";
	cin >> str1;
	cout <<"Enter the number:";
	cin >> num;
	cout <<"Enter the second string:";
	cin >> str2;
	mystrcat(str1,num,str2,str3);
}
mystrcat(string str1,int num,string str2,string str3)
{
	for(int i=0;i<str1.size();i++)
	{
		str3=str3+str1[i];
	}
	str3=str3+s(num);
	for(int i=0;i<str2.size();i++)
	{
		str3=str3+str2[i];
	}
	cout << str3;
}
