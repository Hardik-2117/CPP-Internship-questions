#include<iostream>
using namespace std;
int main( )
{
	char *s[ ]={"DELHI","PUNE","GOA","KOCHI"};
	char *p;
	p=s[1];
	cout<<*p<<endl;// output is P //
	cout<<*(p+2);// output is N //
	return 0;
}
