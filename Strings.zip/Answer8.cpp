#include <bits/stdc++.h>
using namespace std;
void reverseStr(char *str1)
{
int i,len=0;
for(i=0;str1[i]!='\0';i++)
 {
  len++;
 }
for (int i = 0; i < len / 2; i++)
swap(str1[i], str1[len - i - 1]);
}
int main()
{
char str1[50];
cout<<"Enter first string:";
 cin>>str1;
 
 cout<<"\n"<<str1<<" is the original string"<<endl;
reverseStr(str1);
cout << str1<<" is the reverse string";
return 0;
}
