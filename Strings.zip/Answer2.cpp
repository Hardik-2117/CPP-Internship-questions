#include<bits/stdc++.h>
using namespace std;
bool equalIgnoreCase(string str1, string str2)
{
	int i = 0;
	transform(str1.begin(), str1.end(), str1.begin(), ::tolower);
	transform(str2.begin(), str2.end(), str2.begin(), ::tolower);

	int x = str1.compare(str2);
	if (x != 0)
		return false;
	else
		return true;
}
void equalIgnoreCaseUtil(string str1, string str2)
{
	bool res = equalIgnoreCase(str1, str2);
	if (res == true)
		cout << "**Enterd strings are identical**" << endl;
	else
		cout << "**Enterd strings are not identical**" << endl;
}
int main()
{
	string str1, str2;
	cout<<"\n Enter the first string "<<endl;
	cin>>str1;
	cout<<"\n Enter the second string "<<endl;
	cin>>str2;
	equalIgnoreCaseUtil(str1, str2);
}

