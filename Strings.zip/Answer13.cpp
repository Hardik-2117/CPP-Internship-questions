#include<iostream>
using namespace std;
int main(){
	char str[]="wipro";
	char *s=str;
	cout << s[0]<<endl;//output is w//
	cout << s[1]<<endl;//output is i//
	cout << *(s+3);//output is r//
	return 0;
}

