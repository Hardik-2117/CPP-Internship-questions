#include<iostream>
#include<string.h>
using namespace std;
int main() {
   const char *str1="Hello";
   const char *str2="hello";
    
cout<<"String 1:"<<str1<<endl;
cout<<"String 2:"<<str2<<endl;
 
    if (strcmp(str1, str2) == 0)
        cout << "\n**Enterd strings are identical**" << endl;
    else
        cout << "**Enterd strings are not identical**";
  
}
