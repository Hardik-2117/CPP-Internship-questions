#include<iostream>
using namespace std;
int mystrcat(char *str1,char *str2,char *str3);
int main()
{
	char str1[10],str2[10],str3[10];
	cout <<"Enter the first string:";
	cin >> str1;
	cout <<"Enter the second string:";
	cin >> str2;
	mystrcat(str1,str2,str3);
	cout << "Enter the concatenated string:" << str3 <<endl;	
}
mystrcat(char *str1,char *str2,char *str3)
{
	int i=0,j=0;
	while(str1[i]!='\0')
	{
		str3[j]=str1[i];
		i++;
		j++;
	}
	i=0;
	while(str2[i]!='\0')
	{
		str3[j]=str2[i];
		i++;
		j++;
	}
	str3[j]='\0';
}
