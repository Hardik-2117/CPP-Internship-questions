#include<bits/stdc++.h>
using namespace std;
int mystrln(char *str1)
{
	int length=0;
	while(*str1!='\0')
	{
	length++;
	str1++;   //Counting the length.
}
    return length;

}
int main()
{
        //Initializing variable.
	char str1[1000];
	cout<<"\n Enter the first string "<<endl;
	cin>>str1;
	cout<<"Length of the string is:"<<mystrln(str1)<<endl;
}
	//Initializing for loop.
	
	
