#include<iostream>
using namespace std;
int main()
{
	char *ptr="uvwxyzabc";
	cout << 2[ptr]<<endl;//output is w//
	cout << ptr[2]<<endl;//output is w//
	cout << *(ptr+2);//output is w//
}


