#include<iostream>
int R=5;
int Row_numbers(int num){
	int dup=0,count=0,w=0;
	for(int i=0;i<num;i++){
		for(int j=0;j<num-i;j++){
			std::cout<<" ";
		}
		for(int d=w;d<num*num;d++){
			if(d%2!=0){
				dup++;
				for(int s=0;s<d;s++){
					std::cout<<dup;
				}
				count++;
				w=d+1;
				break;
		}
		}
		std::cout<<"\n";
		if(count==num){
			break;
		}
}
}
int Row_backwards(int num){
	int dup=num,count=0,w=0;
	for(int i=0;i<num;i++){
		for(int j=0;j<num-i;j++){
			std::cout<<" ";
		}
		for(int d=w;d<num*num;d++){
			if(d%2!=0){
				for(int s=0;s<d;s++){
					std::cout<<dup;
				}
				dup--;
				count++;
				w=d+1;
				break;
		}
		}
		std::cout<<"\n";
		if(count==num){
			break;
		}
}
}
int Up_down_number(int U){
	int num=U,count=0,w=0,s=0,L,N=0,in=0;
	for(int i=0;i<num;i++){
		for(int j=0;j<num-i;j++){
			std::cout<<" ";
		}
		for(int d=w;d<num*num;d++){
			if(d%2!=0){
				if(d>1){//in this for loop after the d value greater than 1 is executed 
					for(int s=1;s<=in;s++){//this for loop for starting the numbers
					std::cout<<s;
				}
				L=d-in;//it is used for after the excuted the starting number we need to perform other process also that is reverse the numbers.
				for(int e=L;e>N;e--){//in this loop  we are reversing the numbers based on the value of L.
					std::cout<<e;
				}
				}
				if(d==1){// i used this loop for starting number. after that its not in use
				for(int e=d;e>s;e--){
					std::cout<<e;
				}
				}
				count++;//used for counting the rows.....
				w=d+1;//after the first loop we need to skip the present number and continue with nxt number so thats why i used like this
				in++;//it plays a main part in this pattern, after the first iteration , it incremented to 1, the it goes to d>1 condition, there its is used
				break;//break the loop
		}
		}
		std::cout<<"\n";//used for next line
		if(count==num){//when the rows are equal with count in that time it will break over all loop.
			break;
		}
}
}
int Up_number_down_alphabet(int U){
	int num=U,count=0,w=0,s=0,L=64,N=64,in=1;
	char character;
	for(int i=0;i<num;i++){
		for(int j=0;j<num-i;j++){
			std::cout<<" ";
		}
		for(int d=w;d<num*num;d++){
			if(d%2!=0){
				if(d>1){//in this for loop after the d value greater than 1 is executed 
					for(int s=1;s<=in;s++){//this for loop for starting the numbers
					std::cout<<s;
				}
				//L=d-(in+1);//it is used for after the excuted the starting number we need to perform other process also that is reverse the numbers.
				for(int e=L;e>N;e--){//in this loop we are reversing the values of it.
					character=e;//we are taking the value and assign to the character so we get the character of particular ascii number.
					std::cout<<character;
				}
				}
				if(d==1){// i used this loop for starting number. after that its not in use
				for(int e=d;e>s;e--){
					std::cout<<e;
				}
				}
				count++;//used for counting the rows.....
				w=d+1;//after the first loop we need to skip the present number and continue with nxt number so thats why i used like this
				in++;//it plays a main part in this pattern, after the first iteration , it incremented to 1, the it goes to d>1 condition, there its is used
				L++;//here i already used value of l=64 now it will increment for every iteration.
				break;//break the loop
		}
		}
		std::cout<<"\n";//used for next line
		if(count==num){//when the rows are equal with count in that time it will break over all loop.
			break;
		}
}
}
int Diamond_alpha_numeric(int U){
	int dup=0,count=0,w=0,num=U;
	for(int i=0;i<num;i++){//it is starting loop for row numbers..
		for(int j=0;j<num-i;j++){//it is used for space....
			std::cout<<" ";
		}
		for(int d=w;d<num*num;d++){//it is used for finding the odd numbers...
			if(d%2!=0){//if it satisfy this condition then only it is a odd number.....
				dup++;//increment the dup value to start the pattern....
				for(int s=0;s<d;s++){//this loop is used to repeat the number in the dup for odd number of times.
					std::cout<<dup;
				}
				count++;//counting the odd numbers;
				w=d+1;//adding one to d value which helpful to move to the next iteration.......
				break;//break the loop....
		}
		}
		std::cout<<"\n";//used for move to next line.....
		if(count==num){//if this condition is satisfy then only the loop ended....
			break;//break the loop
		}
	}
	//as of now half of the pattern is completed which is numbers part.....
	// now we need to start the alpha pattern in reverse way...
	//for this iam taking the value of w & count....
	int t=(w-2),L=64+(count-1),sp=2;//for t i am subtracting 2 because of the increament happened in the end of the half part and i need to remove one odd value in it..
	//so for that iam subtracting the 2 for t....
	//here iam adding count-1 to the L because the count says how many character are i need to show in the remaining part....
	//count-1 because i need to show remaining half part only so for that we need to subtract 1 to count then we well get exact way...
	char character;//taking a character....
	for(int g=t;g>0;g--){//loop started in reverse way, assigning "t" value to g.....
		if(g%2!=0){//if it satisfy then only it is a odd number...
			for(int h=0;h<sp;h++){//use for adding space in front of it...
				std::cout<<" ";
			}
			for(int x=g;x>0;x--){//from here the alpha characters are printed......
				character=L;//assigning the L value to the character.....
				std::cout<<character;
			}
			L--;//decrement to the value so that the character can changed in every iteration.....
			sp++;//increment of this value , helpful to adding space infornt of a character.....
			std::cout<<"\n";//next line
		}
	}	
}
int Row_number_up_down(int U){
	int n = U, i, j, num = 1, gap;
   gap = n - 1;
   for ( j = 1 ; j <= n ; j++ ){
      num = j;
      for ( i = 1 ; i <= gap ; i++ )
      std::cout << " ";
      gap --;
      for ( i = 1 ; i <= j ; i++ ){
      	if(num<=9)
            std::cout << num;
        else
		    std::cout<<num-9;    
         num++;
      }
      num--;
      num--;
      for ( i = 1 ; i < j ; i++){
         if(num<=9)
            std::cout << num;
        else
		    std::cout<<num-9; 
         num--;
      }
      std::cout << "\n";
   }
	}
int Alpha_numeric_alternate(int U){
	int num=U,L=65,h=65,b=0,w=0,sp=0,f=0,cou=0;
	int dup=L,count=0;
	char character;
	for(int i=0;i<num;i++){//in this loop the number of rows, it will be repeated......
		for(int j=0;j<num-i;j++){//it is used for space purpose.............
			std::cout<<" ";
		}
		for(int d=w;d<num*num;d++){//its used for odd numbers..........
			if(d%2!=0){//if condition satisfy, enter into the loop.......
				if(d>1){
					int e=0;
					int s=dup;//assigning the duplicate value to s......
					for(s;s<=L;s++){
						if(s%2==0){//here if he s value is even then it need to print the e value.....
							std::cout<<e;
							
						}
						else{//if its not a even then.........
							character=s;//the s value is assigned to character......
							std::cout<<character;//here it will printed in the monitor......
							e+=2;//here we to increament the value then only we can get the increament value as 2 4 6 etc...... 
						}
					}
					cou++;//here iam counting the repeating of loop after d==1,.............
					//see why iam here used "cou" varaible means , when the value first time increament then it goes to character part only not increament of value 2,4,etc like that
					//so for that i not able increament seprately , in this case iam taking to confitions one is even and not even(odd condition)....
					//when the first time the loop enter into the character only, means it enter into the else condition....
					// see the below to this else comment of if statement.....
					if(cou%2==0){//if cou is even it enter into the statement..............
					b=f;//here iam assigning the f value to b.............
					for(int m=h;m>=dup;m--){
						if(m%2==0){//same here also if the m is even it will enter into the statement.......
							std::cout<<b;
							b-=2;//decreament the value of 2.....
						}
						else{
							character=m;
							std::cout<<character;
						}	
					}
					}
					else{
						//after the first entering into the character the f value is increased to 2, this value is increasing like this continuesly....
						//so iam not able to decrease the f value, thats why i created one varaible named as "b" which can store the f value....
						//we can able to decrease the b value when ever we need.....
						f+=2;//here iam increament here it will increament first time......
						b=f;//storing the b value.............
						for(int m=h;m>=dup;m--){//it started the loop........
						if(m%2==0){//if m value is even then it enter into the loop......
							b-=2;//here iam decreasing the value of b in the starting only because it is 3rd iteration, if count the iteration of total you may get the clarity of it....
							//in every odd iteration the if value is used it will decrease the value to 2.........
							std::cout<<b;
						}
						else{
							character=m;//already said about it....
							std::cout<<character;
						}
					}
					}
					h++;//here the right half part of the ascii value which i taken seprately is increamented by 1..........
				}
				if(d==1){//it is used for the first iteration only......
					character=L;
					std::cout<<character;
				}
				L++;//it is increament the left half part of ascii value......
				count++;//it is counting the rows.....
				w=d+1;//it is used for when ever the odd number is finded then this is used to continued the iteration to nxt number.............
				std::cout<<"\n";//next line.............
				break;//used for break the loop.......
		}
		
		if(count==num){//if the count of row is equal to num then it will break the entire loop............
			break;
		}
}
}
}
int Consective_series(int U){
	int num=U,w=0,f=0;
	int count=0;
	char character;
	for(int i=0;i<num;i++){//in this loop the number of rows, it will be repeated......
		for(int j=0;j<num-i;j++){//it is used for space purpose.............
			std::cout<<" ";
		}
		for(int d=w;d<num*num;d++){//its used for odd numbers..........
			if(d%2!=0){//if condition satisfy, enter into the loop.......
				for(int g=1;g<=d;g++){//it will repeated the loop......
					if(f==9){//if f=9 then it enter into the if statement.....
					f=0;//if f=9, it makes f=0.......
					std::cout<<f;
					}
					else{//if f!=9 then else part is performed...........
						f++;//increamented every time.....
						std::cout<<f;
					}
				}
				count++;//it is counting the rows.....
				w=d+1;//it is used for when ever the odd number is finded then this is used to continued the iteration to nxt number.............
				std::cout<<"\n";//next line.............
				break;//used for break the loop.......
		}
		
		if(count==num){//if the count of row is equal to num then it will break the entire loop............
			break;
		}
}
}
}
int Diamond_alpha_star(int U){
	int num=U,count=0,w=0,s=0,L,N=0,in=1;
	for(int i=0;i<num;i++){
		for(int j=0;j<num-i;j++){
			std::cout<<" ";
		}
		for(int d=w;d<num*num;d++){
			if(d%2!=0){
				if(d>1){//in this for loop after the d value greater than 1 is executed 
					for(int s=1;s<=in;s++){//this for loop for starting the numbers
					std::cout<<s;
				}
				L=d-in;//it is used for after the excuted the starting number we need to perform other process also that is reverse the numbers.
				for(int e=L;e>N;e--){//in this loop  we are reversing the numbers based on the value of L.
					std::cout<<"*";
				}
				}
				if(d==1){// i used this loop for starting number. after that its not in use
				for(int e=d;e>s;e--){//in this loop the numbers are formed
					std::cout<<e;
				}
				}
				count++;//used for counting the rows.....
				w=d+1;//after the first loop we need to skip the present number and continue with nxt number so thats why i used like this
				in++;//it plays a main part in this pattern, after the first iteration , it incremented to 1, the it goes to d>1 condition, there its is used
				break;//break the loop
		}
		}
		std::cout<<"\n";//used for next line
		if(count==num){//when the rows are equal with count in that time it will break over all loop.
			break;
		}
}
int t=t=(w-2),star=count-2,sp=2;//here i take the w value and subtracting 2 from it removing oen odd number from it...
//count stars can help for forming the stars......
int dup1=count-1,dup2=star;
for(int g=t;g>0;g--){//loop started in reverse way, assigning "t" value to g.....
		if(g%2!=0){//if it satisfy then only it is a odd number...
			for(int h=0;h<sp;h++){//use for adding space in front of it...
				std::cout<<" ";
			}
			for(int x=star;x>=1;x--){//used for * of it......
				std::cout<<"*";
			}
			for(int z=dup1;z>=1;z--){// used for reverse a number....
				std::cout<<z;
			}
			sp++;// increasing the space value.....
			star--;//decreament of star value....
			dup1--;//decreament of reverse number value.....
			std::cout<<"\n";//used for nxt line.................
		}
}
}
void change(int U);
int main(){
	//int R=5;
	int count=0,w=0,n;
	char c1;
	std::cout<<"--------------- **\nMAIN MENU **\n---------------\n1. Row Numbers \n2. Row Numbers Backwards \n3. Up Down Numbers \n4. Up Numbers Down Alphabets \n5. Alpha Numeric Alternate \n6. Consecutive series \n7. Row Number Up Down \n8. Diamond Alpha Numeric \n9. Diamond Alpha Star \n10.SET ROW_LEVEL \n0. EXIT";
	std::cout<<"\nEnter your option (1 to 10) (0 to Exit): _";
	std::cin>>n;
	//std::cout<<"_";
	switch (n){
	case 1:
		//Row numbers
		Row_numbers(R);
		system("pause");
		main();
		break;
	case 2:
		//Row numbers backwards
		Row_backwards(R);
		system("pause");
		main();
		break;
	case 3:
		//up down numbers
		Up_down_number(R);
		system("pause");
		main();
		break;
	case 4:
		//up number down alphabets
		Up_number_down_alphabet(R);
		system("pause");
		main();
		break;
	case 5:
		//Alpha numeric alternate
		Alpha_numeric_alternate(R);
		system("pause");
		main();
		break;
	case 6:
		//Consecutive series
		Consective_series(R);
		system("pause");
		main();
		break;
	case 7:
		//Row Number Up Down
		Row_number_up_down(R);
		system("pause");
		main();
		break;
	case 8:
		//Diamond alpha numeric
		Diamond_alpha_numeric(R);
		system("pause");
		main();
		break;
	case 9:
		//Diamond alpha star
		Diamond_alpha_star(R);
		system("pause");
		main();
		break;
	case 10:
		//set row level
		change(R);
	case 0:
		//exit
		break;
	}	
}
void change(int U){
	int n;
	std::cout<<"current row level : ";
	std::cout<<U;
	std::cout<<"\nSet new row level (1 to 15): _";
	std::cin>>U;
	std::cout<<"\n--------------- **\nMAIN MENU **\n---------------\n1. Row Numbers \n2. Row Numbers Backwards \n3. Up Down Numbers \n4. Up Numbers Down Alphabets \n5. Alpha Numeric Alternate \n6. Consecutive series \n7. Row Number Up Down \n8. Diamond Alpha Numeric \n9. Diamond Alpha Star \n10.SET ROW_LEVEL \n0. EXIT";
	std::cout<<"\nEnter your option (1 to 10) (0 to Exit): _";
	std::cin>>n;
	//std::cout<<"_";
	int R=U;
	switch (n){
	case 1:
		//Row numbers
		Row_numbers(R);
		system("pause");
		main();
		break;
	case 2:
		//Row numbers backwards
		Row_backwards(R);
		system("pause");
		main();
		break;
	case 3:
		//up down numbers
		Up_down_number(R);
		system("pause");
		main();
		break;
	case 4:
		//up number down alphabets
		Up_number_down_alphabet(R);
		system("pause");
		main();
		break;
	case 5:
		//Alpha numeric alternate
		Alpha_numeric_alternate(R);
		system("pause");
		main();
		break;
	case 6:
		//Consecutive series
		Consective_series(R);
		system("pause");
		main();
		break;
	case 7:
		//Row Number Up Down
		Row_number_up_down(R);
		system("pause");
		main();
		break;
	case 8:
		//Diamond alpha numeric
		Diamond_alpha_numeric(R);
		system("pause");
		main();
		break;
	case 9:
		//Diamond alpha star
		Diamond_alpha_star(R);
		system("pause");
		main();
		break;
	case 10:
		//set row level
		change(R);
	case 0:
		//exit
		break;
	}	
}

