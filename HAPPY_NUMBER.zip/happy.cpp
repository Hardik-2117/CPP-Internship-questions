#include<iostream>
int main(){
	int num;
	std::cout<<"Program_name  ";
	std::cin>>num;
	int sq=num*num;
	
	
	while(sq>0){
		int k=0;
		while(sq>0){
			int t=sq%10;
			k+=t*t;
			sq=sq/10;
		}
		
		sq=k;
		if(sq==1){
			std::cout<<"Happy number";
			break;
		}
		else if(sq<=9){
			std::cout<<"Unhappy number";
			break;
		}
	}
	return 0;
}
